#!/usr/bin/env python3
"""
Test script for GlyxEra login system password validation
"""
import re

# Password validation regex (same as in application.py)
PASSWORD_REGEX = re.compile(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{6,20}$')

def test_password(password):
    """Test if password meets validation requirements"""
    return PASSWORD_REGEX.match(password) is not None

# Test cases
test_passwords = [
    ("Demo123", True),      # Valid - meets all requirements
    ("Test123", True),      # Valid - meets all requirements  
    ("Admin123", True),     # Valid - meets all requirements
    ("demo123", False),     # Invalid - no uppercase
    ("DEMO123", False),     # Invalid - no lowercase
    ("Demo", False),        # Invalid - too short, no number
    ("Demo12", True),       # Valid - meets all requirements
    ("Demo1234567890123456789", False),  # Invalid - too long
    ("", False),            # Invalid - empty
    ("Demo@123", True),     # Valid - special char allowed
]

print("🔐 Password Validation Test Results:")
print("=" * 50)

all_passed = True
for password, expected in test_passwords:
    result = test_password(password)
    status = "✅ PASS" if result == expected else "❌ FAIL"
    print(f"{status} | '{password}' -> {result} (expected: {expected})")
    if result != expected:
        all_passed = False

print("=" * 50)
if all_passed:
    print("🎉 All password validation tests PASSED!")
else:
    print("⚠️  Some password validation tests FAILED!")

print("\n📋 Password Requirements:")
print("• 6-20 characters")
print("• At least one uppercase letter (A-Z)")
print("• At least one lowercase letter (a-z)")
print("• At least one number (0-9)")
print("• Optional special characters: @$!%*?&")