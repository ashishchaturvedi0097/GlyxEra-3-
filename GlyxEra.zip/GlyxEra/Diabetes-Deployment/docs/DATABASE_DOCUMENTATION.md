# 📊 GlyxEra Database Documentation

## Overview
GlyxEra uses **SQLite** database for storing user accounts and health assessment results. This document explains the database structure and how to view stored data.

---

## 🗄️ Database Location

**File Name:** `glyxera.db`  
**Location:** `GlyxEra/Diabetes-Deployment/glyxera.db`  
**Type:** SQLite3 Database

---

## 📋 Database Schema

### 1. **Users Table**
Stores registered user accounts with secure password hashing.

| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary Key (Auto-increment) |
| email | VARCHAR(120) | User's Gmail address (Unique) |
| password_hash | VARCHAR(255) | Bcrypt hashed password |
| name | VARCHAR(100) | User's display name |
| created_at | DATETIME | Account creation timestamp |

**Security:** Passwords are hashed using Bcrypt (NOT stored in plain text)

---

### 2. **Assessments Table**
Stores all health assessment results for users.

| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER | Primary Key (Auto-increment) |
| user_id | INTEGER | Foreign Key → users.id |
| assessment_type | VARCHAR(50) | Type: diabetes, blood_pressure, mental_health |
| patient_name | VARCHAR(100) | Patient's name |
| age | INTEGER | Patient's age |
| gender | VARCHAR(10) | Male/Female |
| prediction | VARCHAR(100) | Assessment result |
| risk_level | VARCHAR(50) | Low/Medium/High/Critical Risk |
| confidence | FLOAT | Prediction confidence (0-100%) |
| input_data | TEXT | JSON string of input parameters |
| result_data | TEXT | JSON string of complete results |
| created_at | DATETIME | Assessment timestamp |

---

## 🔍 How to View Database Contents

### Method 1: Using Python Script (Recommended)
```bash
cd Diabetes-Deployment
python view_database.py
```

This will display:
- ✅ All registered users
- ✅ All health assessments
- ✅ Statistics by assessment type
- ✅ Database file information

---

### Method 2: Using SQLite Browser (GUI Tool)

1. **Download DB Browser for SQLite:**
   - Website: https://sqlitebrowser.org/
   - Free and open-source

2. **Open Database:**
   - Launch DB Browser
   - File → Open Database
   - Select `glyxera.db` from project folder

3. **View Tables:**
   - Click "Browse Data" tab
   - Select table: `users` or `assessments`
   - View all stored records

---

### Method 3: Using Command Line
```bash
cd Diabetes-Deployment
sqlite3 glyxera.db

# View all users
SELECT * FROM users;

# View all assessments
SELECT * FROM assessments;

# View assessment statistics
SELECT assessment_type, COUNT(*) FROM assessments GROUP BY assessment_type;

# Exit
.quit
```

---

## 📊 What Gets Stored?

### When User Logs In:
- ✅ User email
- ✅ Hashed password (secure)
- ✅ User name
- ✅ Login timestamp

### When User Completes Assessment:
- ✅ Patient information (name, age, gender)
- ✅ Assessment type (diabetes/blood pressure/mental health)
- ✅ All input parameters (glucose, BMI, blood pressure, etc.)
- ✅ Prediction result
- ✅ Risk level
- ✅ Confidence score
- ✅ Complete result data (JSON format)
- ✅ Timestamp

---

## 🎯 Demonstration for Examiners

### Step 1: Show Database File
```bash
# Navigate to project folder
cd GlyxEra/Diabetes-Deployment

# List files (you'll see glyxera.db)
dir  # Windows
ls   # Linux/Mac
```

### Step 2: Run Database Viewer
```bash
python view_database.py
```

**Output will show:**
- Number of registered users
- All assessment records
- Statistics by assessment type
- Database file size and location

### Step 3: Show in Application
1. Login to application
2. Complete a health assessment
3. Go to "Assessment History" page
4. Show stored assessments with timestamps

### Step 4: Verify in Database
```bash
python view_database.py
```
Show that new assessment appears in database!

---

## 🔐 Security Features

1. **Password Hashing:** Bcrypt algorithm (industry standard)
2. **No Plain Text:** Passwords never stored in readable format
3. **SQL Injection Protection:** SQLAlchemy ORM prevents SQL injection
4. **Session Management:** Secure Flask sessions
5. **Data Validation:** Input validation before database storage

---

## 📈 Database Benefits

✅ **Persistent Storage:** Data survives server restarts  
✅ **User History:** Track all assessments over time  
✅ **Data Analysis:** Query historical health trends  
✅ **Scalable:** Can handle thousands of records  
✅ **Portable:** Single file, easy to backup  
✅ **Standard:** SQLite used by millions of applications  

---

## 🚀 Production Deployment

For production, consider upgrading to:
- **PostgreSQL** (for high traffic)
- **MySQL** (for enterprise use)
- **Cloud Database** (AWS RDS, Azure SQL)

Current SQLite implementation is perfect for:
- ✅ Development
- ✅ Testing
- ✅ Small to medium deployments
- ✅ Academic projects
- ✅ Demonstrations

---

## 📝 Sample Data

### Demo Users (Pre-loaded):
- demo@gmail.com / demo123
- test@gmail.com / test123
- admin@gmail.com / admin123

### After Running Assessments:
Database will contain real assessment data with:
- Patient names
- Health metrics
- Predictions
- Risk levels
- Timestamps

---

## 🎓 For Examiners

**Key Points to Highlight:**

1. **Database Implementation:** Complete SQLite database with proper schema
2. **Data Persistence:** All assessments stored permanently
3. **Security:** Password hashing with Bcrypt
4. **Relationships:** Proper foreign key relationships
5. **History Tracking:** Users can view past assessments
6. **Scalability:** Can store unlimited assessments
7. **Professional:** Industry-standard ORM (SQLAlchemy)

**Live Demonstration:**
1. Show database file exists
2. Run viewer script to show contents
3. Complete assessment in application
4. Show new record in database
5. View assessment history in application

---

## 📞 Technical Details

**Technology Stack:**
- Database: SQLite3
- ORM: Flask-SQLAlchemy
- Security: Flask-Bcrypt
- Language: Python 3.x

**Database Operations:**
- CREATE: New users and assessments
- READ: Login verification, history display
- UPDATE: (Future feature)
- DELETE: Cascade delete on user removal

---

## ✅ Verification Checklist

- [x] Database file created automatically
- [x] Users table with hashed passwords
- [x] Assessments table with all data
- [x] Foreign key relationships
- [x] Timestamps on all records
- [x] Assessment history page
- [x] Database viewer script
- [x] Complete documentation

---

**Last Updated:** 2026  
**Created By:** Ashish Santosh Chaturvedi  
**Project:** GlyxEra - AI-Powered Smart Health Risk Detection
