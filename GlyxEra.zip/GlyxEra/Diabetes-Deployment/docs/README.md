# 🏥 GlyxEra - AI-Powered Health Assessment System

**Professional Health Prediction Platform with Multi-Disease Assessment**

---

## 🌟 Overview

GlyxEra is a comprehensive AI-powered health assessment system that provides accurate predictions for multiple health conditions including Diabetes, Hypertension (Blood Pressure), and Mental Health disorders. Built with Flask and powered by machine learning models, it offers a professional, user-friendly interface for health screening.

---

## ✨ Key Features

### 🔬 Multi-Disease Assessment
- **Diabetes Prediction** - ML-based prediction using 8 health parameters (77.27% accuracy)
- **Blood Pressure Analysis** - Rule-based hypertension risk assessment (79.34% accuracy)
- **Mental Health Screening** - Student & Non-Student assessments (73.02% average accuracy)

### 👥 User Management
- Secure authentication system with Gmail validation
- Admin dashboard with full user management
- Personal assessment history tracking
- Role-based access control (Admin/User)

### 📊 Professional Results
- Comprehensive health reports with confidence scores
- Disease-specific food recommendations
- Personalized medical advice
- Downloadable HTML reports
- Multi-language support (Google Translate integration)

### 🎨 Modern UI/UX
- Responsive Bootstrap 5 design
- Gradient backgrounds and smooth animations
- Professional greeting cards for healthy results
- Clean, intuitive navigation

---

## 🛠️ Technology Stack

- **Backend**: Flask (Python)
- **Database**: SQLAlchemy with SQLite
- **ML Models**: Scikit-learn (Logistic Regression, Random Forest)
- **Frontend**: Bootstrap 5, Font Awesome, JavaScript
- **Authentication**: Flask-Bcrypt for password hashing

---

## 📁 Project Structure

```
GlyxEra/Diabetes-Deployment/
│
├── Model/                          # Trained ML models
│   ├── modelForPrediction.pkl      # Diabetes prediction model
│   ├── standardScalar.pkl          # Feature scaler
│   └── mental_health_models.pkl    # Mental health models
│
├── Dataset/                        # Training datasets
│   ├── diabetes.csv                # Diabetes dataset (768 records)
│   └── Student Mental health.csv   # Mental health dataset (101 records)
│
├── templates/                      # HTML templates
│   ├── home_page.html             # Landing page
│   ├── index.html                 # Dashboard
│   ├── health_assessment.html     # Assessment selection
│   ├── home.html                  # Diabetes form
│   ├── single_prediction.html     # Diabetes results
│   ├── bp_form.html               # Blood pressure form
│   ├── bp_result.html             # Blood pressure results
│   ├── mental_health_form.html    # Mental health form
│   ├── mental_health_result.html  # Mental health results
│   ├── admin_login.html           # Admin authentication
│   ├── user_login.html            # User authentication
│   ├── admin_dashboard.html       # Admin panel
│   └── assessment_history.html    # User history
│
├── static/images/                  # Image assets
│
├── application.py                  # Main Flask application
├── database.py                     # Database models & configuration
├── train_mental_health_model.py   # Mental health model training
├── show_model_accuracy.py         # Terminal accuracy display
├── reset_admin.py                 # Admin reset utility
├── view_database.py               # Database viewer utility
├── requirements.txt               # Python dependencies
├── glyxera.db                     # SQLite database
├── MODEL_ACCURACY_README.md       # Model accuracy documentation
├── DATABASE_README.md             # Database documentation
└── README.md                      # This file
```

---

## 🚀 Installation & Setup

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)
- Google Chrome (recommended browser)

### Step 1: Clone the Repository
```bash
cd Desktop
git clone <repository-url>
cd GlyxEra/Diabetes-Deployment
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Run the Application
```bash
python application.py
```

The application will automatically:
- Initialize the database
- Load ML models
- Open Chrome browser at `http://127.0.0.1:8080`

---

## 📖 Usage Guide

### First Time Setup
1. **Admin Creation**: First user becomes admin automatically
2. **Login**: Use Gmail address and password
3. **Dashboard**: Access all health assessments

### Health Assessments

#### 1️⃣ Diabetes Prediction
- **Parameters**: Gender, Age, Glucose, Blood Pressure, BMI, Skin Thickness, Insulin, Diabetes Pedigree Function
- **Duration**: ~1 minute
- **Output**: Risk level, confidence score, personalized recommendations

#### 2️⃣ Blood Pressure Assessment
- **Parameters**: Age, Gender, Systolic BP, Diastolic BP
- **Duration**: ~30 seconds
- **Output**: BP category (Normal/Elevated/Stage 1/Stage 2/Crisis)

#### 3️⃣ Mental Health Screening
- **Student Assessment**: CGPA-based with AI prediction
- **Non-Student Assessment**: PHQ-9 questionnaire
- **Duration**: ~2 minutes
- **Output**: Risk category, recommendations, treatment suggestions

---

## 🎯 Model Accuracy

| Model | Accuracy | Status |
|-------|----------|--------|
| Diabetes Prediction | 77.27% | ✅ Production Ready |
| Blood Pressure | 79.34% | ✅ Production Ready |
| Depression Detection | 76.19% | ✅ Production Ready |
| Anxiety Detection | 76.19% | ✅ Production Ready |
| Panic Attack Detection | 66.67% | ⚠️ Good |
| **Overall System** | **76.54%** | ✅ **Excellent** |

*View detailed accuracy: Run `python show_model_accuracy.py`*

---

## 🔐 Admin Features

- View all user assessments
- Delete users and their data
- Monitor system usage
- Access complete assessment history

---

## 🛡️ Security Features

- Password hashing with bcrypt
- Session-based authentication
- Gmail-only registration
- SQL injection protection
- CSRF protection

---

## 📊 Database Schema

### Users Table
- `id`, `email`, `password_hash`, `name`, `is_admin`, `created_at`

### Assessments Table
- `id`, `user_id`, `assessment_type`, `patient_name`, `age`, `gender`
- `prediction`, `risk_level`, `confidence`, `input_data`, `result_data`, `created_at`

---

## 🔧 Utility Scripts

### View Model Accuracy
```bash
python show_model_accuracy.py
```

### View Database Contents
```bash
python view_database.py
```

### Reset Admin Account
```bash
python reset_admin.py
```

### Train Mental Health Models
```bash
python train_mental_health_model.py
```

---

## 🎨 Features Highlights

### Disease-Specific Food Recommendations
- **Diabetes**: Low-glycemic foods, whole grains, lean proteins
- **Hypertension**: DASH diet, potassium-rich foods, low sodium
- **Mental Health**: Brain-boosting foods, serotonin-rich options

### Professional Result Pages
- Confidence scores with progress bars
- Patient summary cards
- Medical recommendations
- Downloadable reports
- Multi-language translation

### Greeting Cards
- Congratulatory messages for healthy results
- Motivational quotes
- Personalized wellness tips

---

## 📝 Medical Disclaimer

⚠️ **Important**: This AI prediction system is for informational and educational purposes only. It is NOT a substitute for professional medical advice, diagnosis, or treatment. Always consult with qualified healthcare professionals for medical concerns.

---

## 🤝 Contributing

Contributions are welcome! Please follow these guidelines:
1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

---

## 📄 License

This project is created for educational and demonstration purposes.

---

## 👨‍💻 Developer

**Ashish Santosh Chaturvedi**

---

## 🙏 Acknowledgments

- Dataset sources: Kaggle, UCI Machine Learning Repository
- Bootstrap 5 for responsive design
- Font Awesome for icons
- Google Translate API for multi-language support

---

## 📞 Support

For issues, questions, or suggestions:
- Create an issue in the repository
- Contact the developer

---

## 🔄 Version History

- **v1.0.0** (2026) - Initial release with multi-disease assessment
- Professional UI/UX with greeting cards
- Disease-specific food recommendations
- Admin dashboard and user management

---

**Made with ❤️ for better health awareness**
