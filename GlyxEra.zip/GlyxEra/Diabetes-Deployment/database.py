from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from datetime import datetime

db = SQLAlchemy()
bcrypt = Bcrypt()

class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    name = db.Column(db.String(100))
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    assessments = db.relationship('Assessment', backref='user', lazy=True, cascade='all, delete-orphan')
    
    def set_password(self, password):
        self.password_hash = bcrypt.generate_password_hash(password).decode('utf-8')
    
    def check_password(self, password):
        return bcrypt.check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.email}>'


class Assessment(db.Model):
    __tablename__ = 'assessments'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    assessment_type = db.Column(db.String(50), nullable=False)  # diabetes, blood_pressure, mental_health
    patient_name = db.Column(db.String(100))
    age = db.Column(db.Integer)
    gender = db.Column(db.String(10))
    
    # Results
    prediction = db.Column(db.String(100))
    risk_level = db.Column(db.String(50))
    confidence = db.Column(db.Float)
    
    # Input data (stored as JSON-like text)
    input_data = db.Column(db.Text)
    result_data = db.Column(db.Text)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Assessment {self.assessment_type} - {self.prediction}>'


def init_db(app):
    """Initialize database with app context"""
    db.init_app(app)
    bcrypt.init_app(app)
    
    with app.app_context():
        db.create_all()
        print("[SUCCESS] Database tables created successfully")
        
        # Create demo users if they don't exist
        demo_users = [
            {'email': 'demo@gmail.com', 'password': 'demo123', 'name': 'Demo User', 'is_admin': False},
            {'email': 'test@gmail.com', 'password': 'test123', 'name': 'Test User', 'is_admin': False}
        ]
        
        for user_data in demo_users:
            existing_user = User.query.filter_by(email=user_data['email']).first()
            if not existing_user:
                user = User(email=user_data['email'], name=user_data['name'], is_admin=user_data['is_admin'])
                user.set_password(user_data['password'])
                db.session.add(user)
        
        db.session.commit()
        print("[SUCCESS] Demo users created/verified")
