"""
Admin Reset Tool for GlyxEra
Use this script if admin forgets their credentials
This will remove the admin account and allow creating a new admin
"""

import sqlite3
import os

def reset_admin():
    db_path = 'glyxera.db'
    
    if not os.path.exists(db_path):
        print("Database file not found!")
        print("   No admin exists yet. Just run the application and create one.")
        return
    
    print("\n" + "="*80)
    print("WARNING: ADMIN RESET TOOL - GLYXERA")
    print("="*80)
    print("\nWARNING: This will remove the current admin account!")
    print("   - Admin user will be deleted")
    print("   - Admin's assessments will be deleted")
    print("   - You can create a new admin after this")
    print("   - Regular users will NOT be affected")
    
    confirm = input("\nAre you sure you want to reset admin? (yes/no): ").strip().lower()
    
    if confirm != 'yes':
        print("\nOperation cancelled. Admin account unchanged.")
        return
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if admin exists
        cursor.execute("SELECT id, email, name FROM users WHERE is_admin = 1")
        admin = cursor.fetchone()
        
        if not admin:
            print("\nNo admin account found. You can create a new admin by running the application.")
            conn.close()
            return
        
        admin_id, admin_email, admin_name = admin
        
        print(f"\nCurrent Admin Details:")
        print(f"   Email: {admin_email}")
        print(f"   Name: {admin_name or 'N/A'}")
        
        # Delete admin's assessments first (foreign key constraint)
        cursor.execute("DELETE FROM assessments WHERE user_id = ?", (admin_id,))
        assessments_deleted = cursor.rowcount
        
        # Delete admin user
        cursor.execute("DELETE FROM users WHERE id = ?", (admin_id,))
        
        conn.commit()
        conn.close()
        
        print(f"\nAdmin account removed successfully!")
        print(f"   - Admin user deleted: {admin_email}")
        print(f"   - Admin assessments deleted: {assessments_deleted}")
        print("\nNext Steps:")
        print("   1. Run the application: python application.py")
        print("   2. Browser will open to Admin Login page")
        print("   3. Create new admin account with new credentials")
        print("\n" + "="*80 + "\n")
        
    except Exception as e:
        print(f"\nError: {e}")
        print("   Please contact support or manually delete the database.")

if __name__ == "__main__":
    reset_admin()
