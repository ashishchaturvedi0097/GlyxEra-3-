"""
Database Reset Script
Fixes IntegrityError by resetting database
"""
import os
import sys

db_path = 'glyxera.db'

print("="*60)
print("DATABASE RESET TOOL")
print("="*60)
print("\nThis will delete the database and create a fresh one.")
print("All users and assessments will be removed.")
print("\nSTEPS:")
print("1. Close Flask app (Ctrl+C in terminal)")
print("2. Run this script: python reset_database.py")
print("3. Restart Flask app: python application.py")
print("\n" + "="*60)

if os.path.exists(db_path):
    try:
        os.remove(db_path)
        print(f"\n[OK] Database deleted: {db_path}")
        print("[OK] Restart Flask app to create fresh database")
    except Exception as e:
        print(f"\n[ERROR] Could not delete database: {e}")
        print("\nMANUAL FIX:")
        print("1. Stop Flask app completely")
        print("2. Manually delete glyxera.db file")
        print("3. Restart Flask app")
else:
    print(f"\n[INFO] Database not found: {db_path}")
    print("[INFO] Will be created on next Flask startup")
