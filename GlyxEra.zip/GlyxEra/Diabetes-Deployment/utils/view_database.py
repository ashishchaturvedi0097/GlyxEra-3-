"""
Database Viewer for GlyxEra Health Assessment System
This script displays all stored data in the SQLite database
"""

import sqlite3
from datetime import datetime
import os

def view_database():
    db_path = 'glyxera.db'
    
    if not os.path.exists(db_path):
        print("❌ Database file not found! Please run the application first.")
        return
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    print("\n" + "="*80)
    print("📊 GLYXERA DATABASE VIEWER")
    print("="*80)
    
    # View Users Table
    print("\n👥 USERS TABLE:")
    print("-" * 80)
    cursor.execute("SELECT id, email, name, created_at FROM users")
    users = cursor.fetchall()
    
    if users:
        print(f"{'ID':<5} {'Email':<30} {'Name':<20} {'Created At':<25}")
        print("-" * 80)
        for user in users:
            print(f"{user[0]:<5} {user[1]:<30} {user[2] or 'N/A':<20} {user[3]:<25}")
        print(f"\n✅ Total Users: {len(users)}")
    else:
        print("No users found.")
    
    # View Assessments Table
    print("\n\n🏥 ASSESSMENTS TABLE:")
    print("-" * 80)
    cursor.execute("""
        SELECT a.id, u.email, a.assessment_type, a.patient_name, 
               a.prediction, a.risk_level, a.created_at
        FROM assessments a
        JOIN users u ON a.user_id = u.id
        ORDER BY a.created_at DESC
    """)
    assessments = cursor.fetchall()
    
    if assessments:
        print(f"{'ID':<5} {'User Email':<25} {'Type':<15} {'Patient':<15} {'Result':<20} {'Risk':<15} {'Date':<20}")
        print("-" * 80)
        for assessment in assessments:
            print(f"{assessment[0]:<5} {assessment[1]:<25} {assessment[2]:<15} {assessment[3]:<15} {assessment[4]:<20} {assessment[5]:<15} {assessment[6]:<20}")
        print(f"\n✅ Total Assessments: {len(assessments)}")
        
        # Statistics
        print("\n📈 ASSESSMENT STATISTICS:")
        print("-" * 80)
        
        cursor.execute("SELECT assessment_type, COUNT(*) FROM assessments GROUP BY assessment_type")
        stats = cursor.fetchall()
        for stat in stats:
            print(f"  • {stat[0].replace('_', ' ').title()}: {stat[1]} assessments")
    else:
        print("No assessments found yet.")
    
    # Database Info
    print("\n\n💾 DATABASE INFORMATION:")
    print("-" * 80)
    print(f"  • Database Location: {os.path.abspath(db_path)}")
    print(f"  • Database Size: {os.path.getsize(db_path) / 1024:.2f} KB")
    print(f"  • Last Modified: {datetime.fromtimestamp(os.path.getmtime(db_path)).strftime('%Y-%m-%d %H:%M:%S')}")
    
    conn.close()
    print("\n" + "="*80 + "\n")

if __name__ == "__main__":
    view_database()
