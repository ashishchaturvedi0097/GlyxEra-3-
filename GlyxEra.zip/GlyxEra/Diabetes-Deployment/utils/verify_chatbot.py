"""
Quick Verification Script - Test Chatbot Functionality
Run this to verify chatbot works after cleanup
"""
import json
import os

def test_chatbot():
    print("=" * 60)
    print("CHATBOT FUNCTIONALITY TEST")
    print("=" * 60)
    
    # Check JSON files exist
    files = [
        'Dataset/chatbot_knowledge.json',
        'Dataset/chatbot_trained_knowledge.json'
    ]
    
    print("\n1. Checking JSON files...")
    for file in files:
        if os.path.exists(file):
            print(f"   [OK] {file} - EXISTS")
        else:
            print(f"   [ERROR] {file} - MISSING!")
            return False
    
    # Load and verify chatbot knowledge
    print("\n2. Loading chatbot knowledge...")
    try:
        with open('Dataset/chatbot_knowledge.json', 'r', encoding='utf-8') as f:
            knowledge = json.load(f)
        
        topics = knowledge.get('health_topics', [])
        total_keywords = sum(len(topic.get('keywords', [])) for topic in topics)
        
        print(f"   [OK] Loaded {len(topics)} Q&A pairs")
        print(f"   [OK] Total keywords: {total_keywords}")
    except Exception as e:
        print(f"   [ERROR] Error loading knowledge: {e}")
        return False
    
    # Test sample queries
    print("\n3. Testing sample queries...")
    test_queries = [
        "i m mentally disturb",
        "check my diabetes",
        "what is blood pressure",
        "mental health tips"
    ]
    
    def find_response(query):
        query_lower = query.lower()
        for topic in topics:
            for keyword in topic.get('keywords', []):
                if keyword.lower() in query_lower:
                    return True
        return False
    
    passed = 0
    for query in test_queries:
        if find_response(query):
            print(f"   [OK] '{query}' - MATCH FOUND")
            passed += 1
        else:
            print(f"   [FAIL] '{query}' - NO MATCH")
    
    print("\n" + "=" * 60)
    print(f"RESULT: {passed}/{len(test_queries)} tests passed")
    
    if passed == len(test_queries):
        print("STATUS: [SUCCESS] CHATBOT FULLY FUNCTIONAL")
    else:
        print("STATUS: [WARNING] CHATBOT HAS ISSUES")
    
    print("=" * 60)
    return passed == len(test_queries)

if __name__ == "__main__":
    test_chatbot()
