# GlyxEra - AI-Powered Health Assessment Platform

A comprehensive health assessment system providing AI-powered predictions for diabetes, blood pressure, and mental health conditions with an intelligent chatbot assistant.

## 🚀 Features

- **Diabetes Prediction**: ML-based diabetes risk assessment (77.27% accuracy)
- **Blood Pressure Analysis**: Rule-based BP classification and risk evaluation
- **Mental Health Screening**: PHQ-9 assessment and student mental health evaluation
- **Intelligent Chatbot**: 120 Q&A pairs with 749 keywords covering health topics
- **User Management**: Secure authentication with admin dashboard
- **Assessment History**: Track and review past health assessments

## 📁 Project Structure

```
GlyxEra/Diabetes-Deployment/
├── Dataset/                    # Training data and chatbot knowledge
│   ├── chatbot_knowledge.json
│   ├── chatbot_trained_knowledge.json
│   ├── diabetes.csv
│   ├── CardiacPrediction.xlsx
│   └── Student Mental health.csv
├── Model/                      # Trained ML models
│   ├── modelForPrediction.pkl
│   ├── standardScalar.pkl
│   └── mental_health_models.pkl
├── static/images/              # Application images
├── templates/                  # HTML templates (14 files)
├── utils/                      # Utility scripts
│   ├── reset_admin.py
│   ├── reset_database.py
│   ├── show_model_accuracy.py
│   └── view_database.py
├── docs/                       # Documentation
│   ├── README.md
│   ├── QUICK_START_GUIDE.md
│   ├── DATABASE_DOCUMENTATION.md
│   └── CHATBOT_ENHANCEMENT_SUMMARY.txt
├── application.py              # Main Flask application
├── database.py                 # Database models
├── requirements.txt            # Python dependencies
├── .gitignore                  # Git ignore rules
└── glyxera.db                  # SQLite database
```

## 🛠️ Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd GlyxEra/Diabetes-Deployment
```

2. **Install dependencies**
```bash
pip install -r requirements.txt
```

3. **Run the application**
```bash
python application.py
```

4. **Access the application**
- Open browser at: `http://127.0.0.1:8080`
- First user becomes admin automatically

## 💻 Technology Stack

- **Backend**: Flask, SQLAlchemy
- **Database**: SQLite
- **ML Models**: Scikit-learn, Pickle
- **Frontend**: Bootstrap 5, HTML5, CSS3, JavaScript
- **Authentication**: Flask sessions with password hashing

## 📊 Model Accuracy

- Diabetes Prediction: 77.27%
- Blood Pressure: 79.34% (rule-based)
- Mental Health (Depression): 76.19%
- Mental Health (Anxiety): 76.19%
- Mental Health (Panic): 66.67%

## 🤖 Chatbot Features

- 120 Q&A pairs covering:
  - Diabetes (41 pairs)
  - Blood Pressure (31 pairs)
  - Mental Health (35 pairs)
  - Navigation & General (13 pairs)
- 749 keywords for intelligent matching
- Supportive responses for mental distress
- Direct assessment links for health conditions

## 🔧 Utility Scripts

Located in `utils/` folder:

- **reset_admin.py**: Reset admin credentials
- **reset_database.py**: Clear and reset database
- **show_model_accuracy.py**: Display model performance metrics
- **view_database.py**: View database contents

## 📖 Documentation

Detailed documentation available in `docs/` folder:

- **README.md**: Project overview
- **QUICK_START_GUIDE.md**: Getting started guide
- **DATABASE_DOCUMENTATION.md**: Database schema and usage
- **CHATBOT_ENHANCEMENT_SUMMARY.txt**: Chatbot features and keywords

## 🔐 Security Features

- Gmail-only authentication
- Password hashing with Werkzeug
- Session-based authentication
- Admin role management
- CSRF protection

## 🎯 Assessment Types

1. **Diabetes Prediction**
   - Input: Glucose, BP, BMI, Age, etc.
   - Output: Risk level, confidence score, recommendations

2. **Blood Pressure Check**
   - Input: Systolic, Diastolic readings
   - Output: BP classification, risk assessment

3. **Mental Health Screening**
   - Student: AI-based prediction with PHQ-9
   - Non-Student: Standard PHQ-9 assessment

## 📝 License

[Your License Here]

## 👥 Contributors

[Your Name/Team]

## 📧 Contact

[Your Contact Information]

---

**Note**: This is a health assessment tool for educational purposes. Always consult healthcare professionals for medical advice.
